"""
Gerador de diagrama trajeto-passo.

Lê uma sequência no formato usado em pneumática — A+ B+ A- B- — e gera:
  - o diagrama em ASCII, para conferir rápido no terminal;
  - o diagrama em SVG, para colar no relatório;
  - a tabela de movimentos passo a passo;
  - o aviso de contrapressão (sinal bloqueado) quando o mesmo atuador
    recebe comandos opostos no mesmo ciclo.

Uso:
    python trajeto_passo.py "A+ B+ A- B-"
    python trajeto_passo.py "A+ B+ B- A-" --svg diagrama.svg
    python trajeto_passo.py "A+ (B+ C+) A- (B- C-)"      # movimentos simultâneos
"""

from __future__ import annotations

import argparse
import re
import sys

RECUADO, AVANCADO = 0, 1


# ------------------------------------------------------------------ parsing
def ler_sequencia(texto: str) -> list[list[tuple[str, int]]]:
    """Converte 'A+ (B+ C+) A-' em [[('A',1)], [('B',1),('C',1)], [('A',0)]]."""
    passos: list[list[tuple[str, int]]] = []
    for bloco in re.findall(r"\([^)]*\)|[A-Za-z]\s*[+-]", texto):
        movs = re.findall(r"([A-Za-z])\s*([+-])", bloco)
        if not movs:
            continue
        passos.append([(a.upper(), AVANCADO if s == "+" else RECUADO) for a, s in movs])
    if not passos:
        raise ValueError("Não encontrei nenhum movimento. Exemplo válido: A+ B+ A- B-")
    return passos


def atuadores(passos) -> list[str]:
    vistos: list[str] = []
    for p in passos:
        for nome, _ in p:
            if nome not in vistos:
                vistos.append(nome)
    return sorted(vistos)


def estados(passos, nomes) -> dict[str, list[int]]:
    """Estado de cada atuador em cada passo, começando todos recuados."""
    atual = {n: RECUADO for n in nomes}
    linhas = {n: [RECUADO] for n in nomes}
    for movimentos in passos:
        for nome, destino in movimentos:
            atual[nome] = destino
        for n in nomes:
            linhas[n].append(atual[n])
    return linhas


# ------------------------------------------------------------------- ASCII
def ascii_simples(passos) -> str:
    """Versão em blocos, mais legível que a de rampas em terminal estreito."""
    nomes = atuadores(passos)
    linhas = estados(passos, nomes)
    n = len(passos)
    col = 4

    cab = "       " + "".join(f"{i:<{col}}" for i in range(n + 1))
    out = ["", "  DIAGRAMA TRAJETO-PASSO", "", cab, "       " + "+" + "---+" * n]
    for nome in nomes:
        e = linhas[nome]
        traco = ""
        for i in range(n + 1):
            simbolo = "█" if e[i] == AVANCADO else "·"
            traco += simbolo + ("   " if i < n else "")
        out.append(f"  {nome} 1|  " + traco)
        out.append(f"       |" + "   |" * n)
    out.append("       " + "+" + "---+" * n)
    out.append("")
    out.append("  █ avançado    · recuado")
    return "\n".join(out)


# --------------------------------------------------------------------- SVG
def svg_diagrama(passos, titulo="Diagrama trajeto-passo") -> str:
    nomes = atuadores(passos)
    linhas = estados(passos, nomes)
    n = len(passos)

    mx, my = 74, 58          # margens
    passo_px = 84
    altura = 46              # distância entre 0 e 1
    gap = 46                 # espaço entre atuadores
    largura = mx + passo_px * n + 40
    total = my + len(nomes) * (altura + gap) + 40

    p = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {largura} {total}" '
        f'font-family="IBM Plex Sans, Segoe UI, sans-serif">',
        f'<rect width="{largura}" height="{total}" fill="#f4f2ec"/>',
        f'<text x="{mx-32}" y="30" font-size="15" font-weight="600" fill="#161c22">{titulo}</text>',
    ]

    # grade vertical dos passos
    for i in range(n + 1):
        x = mx + i * passo_px
        p.append(f'<line x1="{x}" y1="{my-14}" x2="{x}" y2="{total-34}" '
                 f'stroke="#d3cec1" stroke-width="1"/>')
        p.append(f'<text x="{x}" y="{my-20}" font-size="11" fill="#5d6670" '
                 f'text-anchor="middle" font-family="IBM Plex Mono, monospace">{i}</text>')

    for k, nome in enumerate(nomes):
        base = my + k * (altura + gap)
        y1, y0 = base, base + altura        # y1 = avançado (em cima)
        e = linhas[nome]

        p.append(f'<text x="{mx-46}" y="{base+altura/2+4}" font-size="14" '
                 f'font-weight="600" fill="#161c22">{nome}</text>')
        p.append(f'<text x="{mx-16}" y="{y1+4}" font-size="10" fill="#5d6670" '
                 f'text-anchor="end" font-family="IBM Plex Mono, monospace">1</text>')
        p.append(f'<text x="{mx-16}" y="{y0+4}" font-size="10" fill="#5d6670" '
                 f'text-anchor="end" font-family="IBM Plex Mono, monospace">0</text>')

        d = [f"M {mx} {y1 if e[0]==AVANCADO else y0}"]
        for i in range(1, n + 1):
            x_ini = mx + (i - 1) * passo_px
            x_fim = mx + i * passo_px
            if e[i] != e[i - 1]:
                d.append(f"L {x_ini} {y1 if e[i-1]==AVANCADO else y0}")
                d.append(f"L {x_fim} {y1 if e[i]==AVANCADO else y0}")
            else:
                d.append(f"L {x_fim} {y1 if e[i]==AVANCADO else y0}")
        p.append(f'<path d="{" ".join(d)}" fill="none" stroke="#0f62c4" '
                 f'stroke-width="2.6" stroke-linejoin="round"/>')

    # rótulos dos movimentos
    for i, movimentos in enumerate(passos):
        texto = " ".join(f"{a}{'+' if s == AVANCADO else '-'}" for a, s in movimentos)
        x = mx + i * passo_px + passo_px / 2
        p.append(f'<text x="{x}" y="{total-14}" font-size="12" fill="#161c22" '
                 f'text-anchor="middle" font-family="IBM Plex Mono, monospace">{texto}</text>')

    p.append("</svg>")
    return "\n".join(p)


# ------------------------------------------------------------- diagnósticos
def verificar_contrapressao(passos) -> list[str]:
    """
    Sinal bloqueado: o atuador recebe o comando de avanço e de recuo dentro do
    mesmo ciclo enquanto o sinal anterior ainda está presente. É o caso clássico
    que exige válvula de rolete escamoteável, temporizador ou método cascata.
    """
    avisos = []
    ordem = [m for passo in passos for m in passo]
    for nome in atuadores(passos):
        movs = [i for i, (a, _) in enumerate(ordem) if a == nome]
        if len(movs) >= 2 and movs[1] - movs[0] <= 1:
            avisos.append(
                f"Atuador {nome}: avanço e recuo em passos vizinhos — "
                f"risco de sinal bloqueado. Use rolete escamoteável, "
                f"temporizador ou método cascata."
            )
    return avisos


def tabela(passos) -> str:
    linhas = ["", "  PASSO   MOVIMENTO   DESCRIÇÃO", "  " + "-" * 48]
    for i, movimentos in enumerate(passos, start=1):
        texto = " ".join(f"{a}{'+' if s == AVANCADO else '-'}" for a, s in movimentos)
        desc = " e ".join(
            f"cilindro {a} {'avança' if s == AVANCADO else 'recua'}" for a, s in movimentos
        )
        linhas.append(f"  {i:^5}   {texto:<11} {desc}")
    return "\n".join(linhas)


# ---------------------------------------------------------------- programa
def main() -> None:
    ap = argparse.ArgumentParser(description="Gera diagrama trajeto-passo a partir da sequência")
    ap.add_argument("sequencia", nargs="?", help='exemplo: "A+ B+ A- B-"')
    ap.add_argument("--svg", metavar="ARQUIVO", help="salva o diagrama em SVG")
    ap.add_argument("--titulo", default="Diagrama trajeto-passo")
    args = ap.parse_args()

    texto = args.sequencia or input("Sequência (ex.: A+ B+ A- B-): ")

    try:
        passos = ler_sequencia(texto)
    except ValueError as erro:
        print(f"Erro: {erro}", file=sys.stderr)
        sys.exit(1)

    print(ascii_simples(passos))
    print(tabela(passos))

    avisos = verificar_contrapressao(passos)
    if avisos:
        print("\n  AVISOS")
        for a in avisos:
            print(f"  ! {a}")
    else:
        print("\n  Nenhum sinal bloqueado detectado nesta sequência.")

    if args.svg:
        with open(args.svg, "w", encoding="utf-8") as f:
            f.write(svg_diagrama(passos, args.titulo))
        print(f"\n  SVG salvo em: {args.svg}")


if __name__ == "__main__":
    main()

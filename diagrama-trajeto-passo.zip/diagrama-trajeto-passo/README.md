# Gerador de diagrama trajeto-passo

Você escreve a sequência do jeito que ela aparece no caderno — `A+ B+ A- B-` —
e o programa desenha o diagrama trajeto-passo, monta a tabela de movimentos e
avisa quando há risco de sinal bloqueado.

## Uso

```bash
python trajeto_passo.py "A+ B+ A- B-"
python trajeto_passo.py "A+ B+ B- A-" --svg diagrama.svg
python trajeto_passo.py "A+ (B+ C+) A- (B- C-)"     # parênteses = simultâneo
```

Saída no terminal:

```
  DIAGRAMA TRAJETO-PASSO

       0   1   2   3   4
       +---+---+---+---+
  A 1|  ·   █   █   ·   ·
       |   |   |   |   |
  B 1|  ·   ·   █   █   ·
       |   |   |   |   |
       +---+---+---+---+

  █ avançado    · recuado

  PASSO   MOVIMENTO   DESCRIÇÃO
  ------------------------------------------------
    1     A+          cilindro A avança
    2     B+          cilindro B avança
    3     A-          cilindro A recua
    4     B-          cilindro B recua
```

Com `--svg`, sai um arquivo vetorial pronto para o relatório — é o mesmo
diagrama, com as linhas em degrau e os passos numerados.

## Detecção de sinal bloqueado

Quando o mesmo atuador avança e recua em passos vizinhos, o sinal do rolete que
manda recuar aparece enquanto o sinal de avanço ainda está presente, e a válvula
não comuta. O programa aponta esses casos:

```
  ! Atuador A: avanço e recuo em passos vizinhos — risco de sinal bloqueado.
    Use rolete escamoteável, temporizador ou método cascata.
```

`A+ B+ A- B-` passa limpo. `A+ A- B+ B-` acusa os dois atuadores.

## Arquivos

- `trajeto_passo.py` — programa e biblioteca
- `exemplo-a-b.svg` — saída de `A+ B+ A- B-`
- `exemplo-simultaneo.svg` — saída de `A+ (B+ C+) A- (B- C-)`

## Como biblioteca

```python
from trajeto_passo import ler_sequencia, svg_diagrama, verificar_contrapressao

passos = ler_sequencia("A+ B+ A- B-")
open("saida.svg", "w").write(svg_diagrama(passos))
print(verificar_contrapressao(passos))
```

## Próximos passos

- [ ] Desenhar também a linha de comando (válvulas e roletes) abaixo do diagrama
- [ ] Gerar automaticamente o circuito pelo método cascata
- [ ] Ler a sequência de um arquivo `.txt` com várias sequências

---

Feito por: Thiagosystems
